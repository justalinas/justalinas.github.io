'''
Jake Hofferbert, Justin Alinas
3.2.7 Design Brief and Visualization
Period 3    2/8/17
'''

import matplotlib.pyplot as plt
import os.path
import numpy as np
import pandas as pd

#sets directory and reads data file
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, 'totalData.csv') 
datafile = open(filename,'r')
data = datafile.readlines()

#creates lists to store data
years = []
violentCrime = []
propCrime = []
totCrime = []
officers = []

#sorts data into proper lists (aggregator)
for line in data[1:]:
    year, violent, prop, total, officer = line.split(',')
    years.append(int(year))
    violentCrime.append(int(violent))
    propCrime.append(int(prop))
    totCrime.append(int(total))
    officers.append(int(officer))

#creates a dataframe
rawData = {'Year': years,
            'Violent Crime': violentCrime,
            'Property Crime': propCrime,
            'Total Crime': totCrime,
            'Officers': officers}
df = pd.DataFrame(rawData, columns = ['Year',
            'Violent Crime',
            'Property Crime',
            'Total Crime',
            'Officers'])


#CREATES BAR CHART FOR CRIME
def crimeBarChart():
    #sets positions and width
    pos = list(range(len(df['Year'])))
    width = 0.5
    
    #creates plot
    fig_crime, ax = plt.subplots(figsize=(15,5))
    
    #creates bar with violent crime data
    plt.bar(pos, df['Violent Crime'],
                width,
                alpha=0.75,
                color='#FF0000',
                label=df['Year'][0:])
    
    #creates bar with property crime data and is grouped with first bar
    plt.bar([p+width for p in pos], df['Property Crime'],
                width,
                alpha=0.75,
                color='#00FF00',
                label=df['Year'][1])
    
    # Set the y axis label
    ax.set_ylabel('Crimes Committed')
    
    # Set the chart's title
    ax.set_title('Year')
    
    # Set the position of the x ticks
    ax.set_xticks([p + 1 * width for p in pos])
    
    # Set the labels for the x ticks
    ax.set_xticklabels(df['Year'])
    
    # Setting the x-axis and y-axis limits
    plt.xlim(min(pos)-width, max(pos)+width*4)
    plt.ylim([0, max(df['Property Crime'])])
    
    # Adding the legend and showing the plot
    plt.legend(['Violent Crime', 'Property Crime'],
                loc='upper right')
    
    fig_crime.show()

#CREATES BAR CHART FOR EMPLOYED OFFICERS
def officerBarChart():
    fig_officer, ax = plt.subplots(figsize = (15, 5))
    width = 0.75
    pos = list(range(len(df['Year'])))
    
    #creates bars
    plt.bar(range(len(df['Year'])), df['Officers'], width, color = 'blue')
    
    #set labels
    ax.set_ylabel('Officers Employed')
    ax.set_xlabel('Year')
    ax.set_xticks([p+0.38 for p in pos])
    ax.set_xticklabels(df['Year'])
    #show bar chart
    fig_officer.show()


crimeBarChart()
officerBarChart()
